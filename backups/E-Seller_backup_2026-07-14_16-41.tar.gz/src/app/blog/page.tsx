import { redirect } from 'next/navigation'

export default function Blog() {
  redirect('/dashboard/blog')
}
