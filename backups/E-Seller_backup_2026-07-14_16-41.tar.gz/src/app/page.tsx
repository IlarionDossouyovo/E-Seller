'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useState, useEffect } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { LanguageSwitcher } from '@/app/i18n/LanguageSwitcher'
import { 
  Sparkles, 
  Search, 
  Package, 
  Palette, 
  Megaphone, 
  Target, 
  BarChart3, 
  Bot, 
  ArrowRight, 
  Play, 
  CheckCircle2,
  Zap,
  Brain,
  Globe,
  Rocket,
  ChevronDown,
  MapPin,
  Mail,
  Phone
} from 'lucide-react'

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
}

const float = {
  animate: {
    y: [0, -20, 0],
    transition: {
      duration: 6,
      repeat: Infinity,
      ease: "easeInOut"
    }
  }
}

// Feature Card Component
// Map feature titles to their dashboard paths
const featurePaths: Record<string, string> = {
  "AI Product Intelligence": "/dashboard/products",
  "AI Supplier Engine": "/dashboard/suppliers",
  "AI Branding Generator": "/dashboard/branding",
  "AI Ads Generator": "/dashboard/ads",
  "AI Positioning Engine": "/dashboard/positioning",
  "AI Market Analytics": "/dashboard/analytics",
  "AI Business Assistant": "/dashboard/assistant",
  "Machine Learning": "/dashboard/ai"
}

function FeatureCard({ 
  icon: Icon, 
  title, 
  description, 
  delay 
}: { 
  icon: any, 
  title: string, 
  description: string, 
  delay: number 
}) {
  const href = featurePaths[title] || "/dashboard"
  
  return (
    <Link href={href}>
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay }}
        whileHover={{ scale: 1.02, y: -5 }}
        className="glass-card p-6 group cursor-pointer relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-electron-blue/5 to-electron-purple/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <div className="relative z-10">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-electron-blue to-electron-purple flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
            <Icon className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-xl font-semibold mb-2 font-[var(--font-sora)]">{title}</h3>
          <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
        </div>
      </motion.div>
    </Link>
  )
}

// Navigation Component
function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass-card !bg-electron-black/90 py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <motion.div 
          whileHover={{ scale: 1.05 }}
          className="flex items-center gap-2"
        >
          <Image src="/logo.svg" alt="E-Seller" width={40} height={40} className="w-10 h-10 rounded-xl" />
          <span className="text-xl font-bold font-[var(--font-sora)]">E-Seller</span>
        </motion.div>
        
        <div className="hidden md:flex items-center gap-8">
          {['Fonctionnalités', 'À propos', 'Blog', 'FAQ'].map((item) => (
            <motion.a 
              key={item}
              href={item === 'Fonctionnalités' ? `#${item.toLowerCase()}` : `/${item.toLowerCase()}`}
              whileHover={{ color: '#0066FF' }}
              className="text-gray-300 hover:text-white transition-colors"
            >
              {item}
            </motion.a>
          ))}
        </div>

        <a 
          href="/dashboard"
          className="bg-gradient-to-r from-electron-blue to-electron-purple px-6 py-2 rounded-xl font-semibold text-sm hover:scale-105 transition-transform inline-block"
        >
          Essai gratuit
        </a>
        <LanguageSwitcher />
      </div>
    </motion.nav>
  )
}

// Hero Section
function Hero() {
  const { scrollY } = useScroll()
  const y = useTransform(scrollY, [0, 500], [0, 150])
  const opacity = useTransform(scrollY, [0, 300], [1, 0])

  return (
    <section className="min-h-screen relative overflow-hidden flex items-center justify-center">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-electron-gradient">
        {/* Grid Pattern */}
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `linear-gradient(rgba(0,102,255,0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(0,102,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }} />
        
        {/* Glowing Orbs */}
        <motion.div 
          animate={{ 
            x: [0, 100, 0],
            y: [0, -50, 0],
          }}
          transition={{ duration: 20, repeat: Infinity }}
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-electron-blue/20 rounded-full blur-[120px]" 
        />
        <motion.div 
          animate={{ 
            x: [0, -100, 0],
            y: [0, 50, 0],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-electron-purple/20 rounded-full blur-[120px]" 
        />
      </div>

      <motion.div 
        style={{ y }}
        className="relative z-10 text-center max-w-5xl mx-auto px-6"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8"
        >
          <Sparkles className="w-4 h-4 text-electron-blue" />
          <span className="text-sm text-gray-300">L'IA qui révolutionne l'e-commerce</span>
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl font-bold mb-6 font-[var(--font-sora)] leading-tight"
        >
          De l'idée au scaling
          <br />
          <span className="gradient-text">en 1 seule plateforme</span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto"
        >
          Remplacez 10 outils en 1 seule. Trouvez des produits gagnants, créez votre marque automatiquement, lancez des campagnes publicitaires performantes.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a 
            href="/dashboard"
            className="group bg-gradient-to-r from-electron-blue to-electron-purple px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 glow-blue cursor-pointer inline-flex hover:scale-105 transition-transform"
          >
            Commencer gratuitement
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
          <a 
            href="/store"
            className="glass-card px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 cursor-pointer hover:scale-105 transition-transform"
          >
            <Play className="w-5 h-5" />
            Voir la démo
          </a>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-16 flex items-center justify-center gap-8 text-gray-500"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-electron-blue" />
            <span className="text-sm">Gratuit pendant 14 jours</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-electron-blue" />
            <span className="text-sm">Sans carte bancaire</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-electron-blue" />
            <span className="text-sm">Annulation facile</span>
          </div>
        </motion.div>
      </motion.div>

      <motion.div 
        style={{ opacity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 2, repeat: Infinity }}>
          <ChevronDown className="w-8 h-8 text-gray-500" />
        </motion.div>
      </motion.div>
    </section>
  )
}

// Features Section
function Features() {
  const features = [
    {
      icon: Search,
      title: "AI Product Intelligence",
      description: "Recherche produit via IA, analyse des tendances TikTok/Meta/Google, score produit et détection de produits viraux."
    },
    {
      icon: Package,
      title: "AI Supplier Engine",
      description: "Intégration fournisseurs, matching intelligent, calcul des marges et optimisation logistique."
    },
    {
      icon: Palette,
      title: "AI Branding Generator",
      description: "Génération nom de marque, logo, identité visuelle, packaging et storytelling automatique."
    },
    {
      icon: Megaphone,
      title: "AI Ads Generator",
      description: "Création vidéos TikTok Ads, scripts UGC, analyse des ads concurrents et recommandations budget."
    },
    {
      icon: Target,
      title: "AI Positioning Engine",
      description: "Définition client cible, angle marketing automatique, analyse concurrence et offres irrésistibles."
    },
    {
      icon: BarChart3,
      title: "AI Market Analytics",
      description: "Dashboard temps réel avec analyse ROI, CPA, ROAS et prédiction des tendances."
    },
    {
      icon: Bot,
      title: "AI Business Assistant",
      description: "Chat intelligent type GPT capable de donner des stratégies et optimiser vos campagnes."
    },
    {
      icon: Brain,
      title: "Machine Learning",
      description: "Analyse comportement utilisateur et recommandations personnalisées basées sur vos données."
    }
  ]

  return (
    <section id="fonctionnalités" className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-electron-blue text-sm font-semibold uppercase tracking-wider">Fonctionnalités</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6 font-[var(--font-sora)]">
            Tout ce dont vous avez besoin
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Une plateforme complète qui remplace 10 outils différents
          </p>
        </motion.div>

        <motion.div 
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature, i) => (
            <FeatureCard key={i} {...feature} delay={i * 0.1} />
          ))}
        </motion.div>
      </div>
    </section>
  )
}

// Stats Section
function Stats() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-electron-blue/10 to-electron-purple/10" />
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-4 gap-8"
        >
          {[
            { number: '10K+', label: 'Utilisateurs actifs' },
            { number: '50M+', label: 'Produits analysés' },
            { number: '95%', label: 'Satisfaction client' },
            { number: '24/7', label: 'Support IA' }
          ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl font-bold gradient-text mb-2 font-[var(--font-sora)]">{stat.number}</div>
              <div className="text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

// Pricing Section
// CTA Section
function CTA() {
  return (
    <section className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-electron-blue/20 via-electron-purple/10 to-electron-black" />
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative z-10 max-w-4xl mx-auto text-center px-6"
      >
        <Rocket className="w-16 h-16 mx-auto mb-8 text-electron-blue" />
        <h2 className="text-4xl md:text-5xl font-bold mb-6 font-[var(--font-sora)]">
          Prêt à révolutionner votre e-commerce ?
        </h2>
        <p className="text-xl text-gray-400 mb-10">
          Rejoignez des milliers d'entrepreneurs qui font confiance à E-Seller
        </p>
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-gradient-to-r from-electron-blue to-electron-purple px-10 py-4 rounded-xl font-semibold text-lg glow-blue"
        >
          Essai gratuit de 14 jours
        </motion.button>
        <p className="mt-6 text-gray-500 text-sm">
          Aucune carte bancaire requise • Annulation à tout moment
        </p>
      </motion.div>
    </section>
  )
}

// Contact & Map Section
function ContactSection() {
  return (
    <section id="contact" className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Notre Localisation</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
           Venez nous rendre visite dans nos bureaux
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="bg-gray-800/50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-6">Contactez-nous</h3>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-electron-blue/20 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-electron-blue" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Adresse</h4>
                    <p className="text-gray-400 text-sm">Cotonou<br />Bénin</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-electron-purple/20 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-electron-purple" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Email</h4>
                    <p className="text-gray-400 text-sm">electronbusiness07@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-green-500" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Téléphone</h4>
                    <p className="text-gray-400 text-sm">+229 01 97700347</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Map */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="h-[400px] rounded-2xl overflow-hidden bg-gray-800"
          >
            <iframe
              src="https://www.openstreetmap.org/export/embed.html?bbox=2.4200%2C6.3500%2C2.4400%2C6.3700&layer=mapnik&marker=6.3600%2C2.4300"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              loading="lazy"
              title="Notre localisation"
            />
          </motion.div>
        </div>

        <p className="text-center text-gray-500 text-sm mt-8">
          <a 
            href="https://www.openstreetmap.org/?mlat=6.3600&mlon=2.4300#map=17/6.3600/2.4300" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:text-white underline"
          >
            Voir sur OpenStreetMap
          </a>
        </p>
      </div>
    </section>
  )
}

// Footer
function Footer() {
  return (
    <footer className="py-16 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-electron-blue to-electron-purple flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold font-[var(--font-sora)]">E-Seller</span>
            </div>
            <p className="text-gray-400 text-sm">
              La plateforme SaaS IA qui révolutionne l'e-commerce.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Produit</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Fonctionnalités</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Tarifs</a></li>
              <li><a href="#" className="hover:text-white transition-colors">API</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Entreprise</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="/a-propos" className="hover:text-white transition-colors">À propos</a></li>
              <li><a href="/blog" className="hover:text-white transition-colors">Blog</a></li>
              <li><a href="/faq" className="hover:text-white transition-colors">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Légal</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Confidentialité</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Conditions</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Mentions légales</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © 2024 E-Seller by ELECTRON. Tous droits réservés.
          </p>
          <div className="flex items-center gap-4">
            <Globe className="w-5 h-5 text-gray-500" />
            <span className="text-gray-500 text-sm">Français</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default function Home() {
  return (
    <main className="bg-electron-black min-h-screen">
      <Navbar />
      <Hero />
      <Stats />
      <Features />
      <CTA />
      <ContactSection />
      <Footer />
    </main>
  )
}
